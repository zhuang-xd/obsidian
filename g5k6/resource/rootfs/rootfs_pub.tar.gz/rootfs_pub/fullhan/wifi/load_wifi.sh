#!/bin/sh

echo "dev, GPIO19, 0, 0" > /proc/driver/pinctrl
echo 19 > /sys/class/gpio/export
echo out > /sys/class/gpio/GPIO19/direction
echo 1 > /sys/class/gpio/GPIO19/value
cat /sys/class/gpio/GPIO19/value
echo 19> /sys/class/gpio/unexport
echo 1 > /sys/class/fhmci/mmc_rescan

sleep 2

ls /sys/bus/sdio/devices

insmod aic8800_bsp.ko
insmod aic8800_fdrv.ko

ifconfig wlan0 up

