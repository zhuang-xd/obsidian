#!/bin/bash -e

cat /proc/deferred_initcalls

cd media
./load_media.sh || true
cd ..

cd clock
./clock_diff.sh || true
./dev_diff.sh || true
cd ..

udevstart || true

#cd wifi
#./load_wifi.sh
#cd ..

