#!/bin/sh

insmod osal.ko
insmod xbus_rpc.ko policy=1
insmod vmm_rpc.ko