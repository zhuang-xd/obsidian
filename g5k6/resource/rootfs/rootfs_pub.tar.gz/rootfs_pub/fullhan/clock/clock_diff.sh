#!/bin/sh

#echo 'isp_bus_clk,enable,100000000' > /proc/driver/clock
#echo 'veu_bus_clk,enable,128500000' > /proc/driver/clock
#echo 'vicap_clk,enable,180000000' > /proc/driver/clock
echo 'rtc_gate,enable,0' > /proc/driver/clock
echo 'ca7_core_clk,enable,450000000' > /proc/driver/clock
echo 'usb2_ahb_clk,enable,32125000' > /proc/driver/clock


echo 'rtc_gate,disable,0' > /proc/driver/clock
echo 'sensor1_clk,disable,0' > /proc/driver/clock
echo 'pwm_clk,disable,0' > /proc/driver/clock
echo 'stm0_clk,disable,0' > /proc/driver/clock
echo 'stm1_clk,disable,0' > /proc/driver/clock
echo 'ephy0_ref_clk,disable,0' > /proc/driver/clock
echo 'efuse_clock,disable,0' > /proc/driver/clock
echo 'sadc_clk,disable,0' > /proc/driver/clock

#no gate
echo 'nn_clk,disable,0' > /proc/driver/clock
echo 'usb2_ahb_clk,disable,0' > /proc/driver/clock


cat /proc/driver/clock
