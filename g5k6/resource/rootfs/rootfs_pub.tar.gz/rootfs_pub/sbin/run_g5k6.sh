#!/bin/bash -e

cd /fullhan/ && ./load_fastboot_modules_MC632X.sh

cd /mnt/data && ./run.sh

sleep 1

mount -t vfat /dev/mmcblk0p1 /mnt/sd
mount -t jffs2 /dev/mtdblock6 /start