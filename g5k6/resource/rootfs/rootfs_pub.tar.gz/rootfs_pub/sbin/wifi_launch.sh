#!/bin/sh

echo "dev, GPIO19, 0, 0" > /proc/driver/pinctrl
echo 19 > /sys/class/gpio/export
echo out > /sys/class/gpio/GPIO19/direction
echo 1 > /sys/class/gpio/GPIO19/value
cat /sys/class/gpio/GPIO19/value
echo 19> /sys/class/gpio/unexport
echo 1 > /sys/class/fhmci/mmc_rescan

sleep 2

insmod aic8800_bsp.ko
insmod aic8800_fdrv.ko

ifconfig wlan0 up


./wpa_supplicant -Dnl80211 -iwlan0 -c./wpa_supplicant.conf &
./iwconfig wlan0

udhcpc -i wlan0 -t 10 -b
